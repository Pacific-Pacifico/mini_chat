package com.example.demo.exception;

import java.util.Date;

public class ExeptionMessage {

	
	private String message;
	private Date timestamp;
	
	public ExeptionMessage() {}
	
	public ExeptionMessage(String message, Date timestamp) {
		super();
		this.message = message;
		this.timestamp = timestamp;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
}

package com.example.demo.ui.controller;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ui.model.request.UpdateUserdetailRequestModel;
import com.example.demo.ui.model.request.UserdetailRequestModel;
import com.example.demo.ui.model.response.UserRest;

@RestController
@RequestMapping("user")
public class UserController {
	
	Map<String, UserRest> users;
	
	@GetMapping
	public String getUser(@RequestParam(value="page", defaultValue="1") int page,
			@RequestParam(value="limit" , defaultValue="100") int i)
	{
		return "get User Called with page= "+page+" and Limit= "+i;
	}
	
	
	
	@GetMapping(path="/{userid}",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<UserRest> getUser(@PathVariable String userid)
	{
		String num=null;
		int len=num.length();
		
		if(users.containsKey(userid))
			return new ResponseEntity<>(users.get(userid),HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping(
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			consumes  = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<UserRest> createUser(@Valid
			@RequestBody UserdetailRequestModel userDetails)
	{

		
		UserRest returnValue= new UserRest();
		returnValue.setFirst_name(userDetails.getFirst_name());
		returnValue.setLast_name(userDetails.getLast_name());
		returnValue.setEmail(userDetails.getEmail());
		//returnValue.setUserid(userid);
		
		String userId=UUID.randomUUID().toString();
		returnValue.setUserid(userId);
				users= new HashMap<String, UserRest>();
				users.put(userId, returnValue);
		
		return new ResponseEntity<UserRest>(returnValue,HttpStatus.OK);
		
	}
	
	@PutMapping	(path="/{userId}",	produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			consumes  = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	
	public ResponseEntity<UserRest> updateUser(@PathVariable String userId,@Valid @RequestBody UpdateUserdetailRequestModel userDetails)
	{
		UserRest storedDetails= users.get(userId);
		storedDetails.setFirst_name(userDetails.getFirst_name());
		storedDetails.setLast_name(userDetails.getLast_name());
		users.put(userId, storedDetails);
		return new ResponseEntity<UserRest>(storedDetails,HttpStatus.OK);
	}
	
	@DeleteMapping(path="/{id}")
	public ResponseEntity<Void> deleteUser(@PathVariable String id)
	{
		users.remove(id);
		return ResponseEntity.noContent().build();
	}
	
	

}

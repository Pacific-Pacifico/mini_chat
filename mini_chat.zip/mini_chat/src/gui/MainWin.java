package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainWin extends JFrame implements ActionListener
{	
	Container c;
	JButton invite,logout;
	JLabel l_settings;
	
	public MainWin()
	{
		c=this.getContentPane();
		c.setLayout(null);
		invite=new JButton("invite");
		logout=new JButton("logout");
		l_settings=new JLabel("settings");
		windowSetter();
		boundSetter();
		componentsAdder();
		eventSetter();
	}
	
	void boundSetter()
	{
		invite.setBounds(25,50 ,75 ,25 );
		logout.setBounds(125,50 , 75,25 );
		l_settings.setBounds(225,40,75,50);
	}
	
	void windowSetter()
	{
		setTitle("Mini Chat");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(250,50,800,700);
		setResizable(false);
	}
	
	void componentsAdder()
	{
		c.add(invite);
		c.add(logout);
		c.add(l_settings);
	}
	
	void eventSetter()
	{
		invite.addActionListener(this);
		logout.addActionListener(this);
		l_settings.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==invite)
		{
			String input = JOptionPane.showInputDialog(this, "Enter email:");
			db.VerifyExistence ve = new db.VerifyExistence();
			int result = ve.doesExists("id", "id_table", input);
			if (result == 1) 
			{
				JOptionPane.showMessageDialog(this, "Sorry.. Entered email already exists in database.");
			}
			else if(result==0)
			{
				JOptionPane.showMessageDialog(this, "invitation sent!! u will be notified when accepted");
			}
//			dispose();
		}
		else if(e.getSource()==logout)
		{
			new account.Welcome();
			dispose();
		}
	}
	
	public static void main(String[] args) 
	{
		MainWin mw=new MainWin();
	}
}
